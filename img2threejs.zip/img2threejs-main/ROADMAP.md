# img2threejs Roadmap

Where img2threejs is going: from rebuilding one object at a time to generating whole playable
worlds from reference images. For the full technical specification and acceptance criteria of
in-flight work, see [docs/UPGRADE_PLAN.md](docs/UPGRADE_PLAN.md).

Each release has one theme. That is deliberate — a version people can name is a version people
can plan around.

## Shipped

| Version | Theme | Date | Highlights |
|---|---|---|---|
| v1.0 | Object pipeline | 2026-07-15 | Staged sculpt pipeline (blockout through optimization), render-vs-reference review loop, action-ready runtime hierarchy |
| v1.1 | Detail-first analysis | 2026-07-15 | Required `detailInventory` artifact (gloss, bevel, fasteners, linework, stains), strict-quality gate blocking shallow specs before codegen |
| v1.2 | Humanoid character generator | 2026-07-21 | Character/hybrid domain detection, anatomy-aware track, proportion-lock and feature-placement gated passes, per-part character materials |
| v1.3 | Quality & efficiency (Divine Eye) | 2026-07-22 | Deterministic multi-signal review harness, input-integrity and geometry-truth gates, reference-grounded texture/material analysis, CIEDE2000 colour math |
| v1.4 | Weapon Pipeline | 2026-07-25–26 | CS2 image-matched reconstruction, provenance-aware intake and local search, projection-first finishes, family-specific adapters, structural review and component-coverage gates |
| v1.5 | The Character Update | 2026-08-12 | Skeleton derived from the component tree and bound to `SkinnedMesh` geometry, geodesic skinning, hair as a five-stage subsystem with a hard scalp-exposure gate, chirality gates, interior-difference review, `tapered-sweep`, material pipeline with a blocking acceptance gate, resumable workflow state |
| v1.5.2 | Character rigging & animation | 2026-08-25 | Clip measurement vocabulary and classifier, corrected loop rule (poseReturn, not travel), proximity weight blending, topology-driven chain resolution, foot-contact gate, and the G1-G10 gate suite where an unmeasured gate reports `unevaluated` rather than a pass |
| v2.0 | The Plugin Update — plugin ecosystem & API | 2026-09-05 | Domain registry (`forge/_shared/domains/`), pull-based spec augmentation with raise-only quality floors, emission-target socket with provenance, per-plugin blocking gates, the img2 harness (`install/add/doctor/sync/capabilities`); CS2 extracted into `plugin-cs2`, `animated-character` served by `plugin-character`, the base names no domain. Pulled forward from the original Procedural World bundle |

### v1.2 — Humanoid character generator

Characters and hybrid subjects became first-class citizens of the pipeline, alongside a round of
engine work on the code generator itself.

- **Character / hybrid domain detection** — assessment recognises character-like form language and
  routes the reconstruction through an anatomy-aware track instead of the hard-surface object path.
- **Humanoid component template** — measured head-unit proportions, facial landmark placement, and
  pose alignment emitted from the assessment stage.
- **Proportion-lock build pass** — a gated pass enforcing anatomical proportion correctness before
  any form or material work proceeds.
- **Feature-placement build pass** — a gated pass placing and validating facial and body landmarks
  against the reference.
- **Per-part character materials** — skin, hair, cloth, and accessory materials wired into the
  detail machinery, for stylized figures with recognisable likeness.
- **Surface-topology classification** — parts classified by surface topology to drive more accurate
  geometry choices, with per-part colour / RGBA recipes for tighter reference matching.
- **Real extrude / lathe / tube geometry** — genuine geometry generation replaced the prior
  approximations; plus tier-1 diagnostics and content-hash caching across passes.

### v1.3 — Quality & efficiency (Divine Eye)

The review harness became deterministic-first: signals are computed by scripts, and the model's
judgment is spent only where a script cannot decide.

- **Divine Eye** — a deterministic multi-signal ensemble (`divine_eye.py`): IoU and scale hard
  gates; proportion, symmetry-parity, pHash, SSIM, edge, blowout, flatness, and tonal-parity soft
  signals; self-uncertainty `probe` routing.
- **Input integrity** — reference admission and intake-correctness cross-checks, property
  auto-binding, shared pHash.
- **Geometry truth** — curve-sweep, a flatness gate, and Blum lathe-profile derivation.
- **Multi-angle** — degenerate-view detection with reference-free self-consistency, plus
  auto-framing.
- **Eye judgment layers** — a gated VLM check, per-feature verification, a bounded stop policy, and
  a calibration harness (report-only, with a separation check).
- **Texture-finish analysis** — classifies finish (gem-metal / gemstone / painted-metal /
  worn-composite / brushed-steel / plastic / `candy-coat`) and writes doc-grounded
  `MeshPhysicalMaterial` scalars. The `candy-coat` recipe exists so a saturated anodized or doppler
  coat keeps its hue instead of the environment stealing it.
- **Reference-grounded gradient stops** — foreground-masked per-band median sampling extracts a
  material's true gradient from the reference instead of hand-guessing it, and flags blue-leaning
  stops that would collapse to blue under tone-mapping.
- **CIEDE2000 colour math** — full ΔE00 (`_shared/color_metrics.py`), verified against the canonical
  Sharma test pairs, feeding report-only `hue_zone_parity` and `specular_wash` signals that catch
  "purple rendered blue" where luma and structure signals cannot.
- **Objectness** — a pure-stdlib HOG-like descriptor and cosine similarity, wired in as a soft
  signal plus a reconstruction-mode rescue.
- **Efficiency** — per-module codegen cache with neighbour invalidation.
- **Presentation** — reference-conditional post-fx (DOF / bloom) kept strictly off the evaluation
  path, so bloom cannot blow highlights the gate is measuring.

## Roadmap

| Version | Theme | Primary goal | Highlights |
|---|---|---|---|
| v1.0 | Object pipeline | Shipped | Staged sculpt pipeline (blockout through optimization), render-vs-reference review loop, action-ready runtime hierarchy |
| v1.1 | Detail-first analysis | Shipped | Required `detailInventory` artifact (gloss, bevel, fasteners, linework, stains), strict-quality gate blocking shallow specs before codegen |
| v1.2-gates | Portable structural gates | In progress | Host-specific tool-call enforcement is deferred; portable ledger, geometry, evidence, and report gates run in forge scripts. |
| v1.2 | Humanoid character generator | Shipped | Character/hybrid domain detection, anatomy and facial landmarks, proportion-lock and feature-placement build passes, per-part character materials |
| v1.3 | Quality & efficiency (Divine Eye) | Shipped | Deterministic review harness, input-integrity and geometry-truth gates, projection-first texture/material analysis, CIEDE2000 colour math |
| v1.4 | Weapon Pipeline | Shipped | CS2 image-matched reconstruction, provenance-aware intake, projection-first finishes, family-specific adapters, structural and component-coverage gates |
| v1.5 | Character Pipeline | Shipped | Component-derived skeleton bound to `SkinnedMesh` geometry · geodesic skinning · hair subsystem across all five stages · chirality gates · interior-difference review · `tapered-sweep` · material pipeline · resumable workflow state. Not shipped: `hairProfile` compiler, IK, pose-sweep gating, clothing |
| v2.0 | The Plugin Update | Shipped | Domain registry · pull-based spec augmentation with raise-only floors · emission-target socket · per-plugin blocking gates · img2 harness · CS2 and animated-character extracted into installed plugins |
| **v2.1** | Character plugin split | Finish the v2.0 split | Round out the v2.0 plugin split: extract the in-repo `character` domain into `plugin-character`, so the base names no domain. CS2 and the full character workflow (anatomy + rig) then ship entirely from external plugins. |
| **v2.2** | Environment Pipeline | Build scenes, not just objects | Buildings · rooms · streets · trees & vegetation · terrain-aware generation · multi-object reconstruction |
| **v2.3** | Game Pipeline | Game-ready assets | Unity exporter · Unreal exporter · Blender bridge · FBX / OBJ / glTF improvements · LOD generation · collision mesh generation |
| **v2.4** | Animation Pipeline | Move assets into production | Auto rigging · auto skin weights · Mixamo compatibility · facial rig · lip-sync preparation · animation-ready exports |
| **v2.5** | AI Studio | Cut the manual work | Web UI · drag & drop workflow · batch processing · visual prompt builder · project management · cloud rendering · public showcase integration |
| **v3.0** | Procedural World Generation | Whole worlds from reference images | Multi-view reconstruction · large scene generation · semantic world understanding · procedural city generation · interior reconstruction · multi-agent generation pipeline |

### Release names

- **v1.5 — The Character Update**
- **v2.0 — The Plugin Update**
- **v2.1 — The Character Split**
- **v2.2 — The Environment Update**
- **v2.3 — The Game Pipeline Update**
- **v2.4 — The Animation Update**
- **v2.5 — The AI Studio Update**
- **v3.0 — The Procedural World Update**

## Version details

### v1.4 — The Weapon Update · *shipped 2026-07-25–26*

v1.4 establishes image-matched reconstruction for CS2 hard-surface assets. The pipeline records
reference admission, family/subtype identity, metadata and texture provenance, exactness tier, and
hidden-region confidence before authoring geometry. It defaults patterned finishes, decals, and skin
surfaces to a de-lit reference projection, rather than presenting a procedural approximation as an
exact match.

The initial family route covers supported knives and the Glock-18 with dedicated component contracts.
Review now combines fixed and orbit renders with family, finish, projection, critical-detail,
geometry-integrity, and component-coverage gates. The v1.4.1 hardening update also requires
map-stripped blockout evidence and ordered pass credit, so a fused or incomplete assembly cannot pass
on the strength of a projected texture alone.

### v1.5 — The Character Update

*Shipped 2026-08-12.*

Characters became a first-class subject rather than a stylized approximation. A skeleton is derived
from the component tree — never authored beside it — and bound to real `SkinnedMesh` geometry through
one shared `Skeleton` and exactly one weight helper, with weights from geodesic distance measured
through the solid. Hair got its own subsystem across all five stages, gated before its generators
were written, because the failure it exists to prevent had already shipped four wrong fixes. Left and
right became an importable constant with two different gates, because a rotated limb pair and a pair
wrong the same way on both sides are different defects. Review learned to measure inside the
silhouette, after an outline metric scored a deleted face identically to a finished one. Optional
local SAM2 masks, MediaPipe face/pose landmarks and Depth Anything V2 relative-depth priors feed
provenance-backed evidence into intake without changing the zero-dependency core or gaining authority
over geometry and review gates. Resumable, evidence-backed workflow state lets character intake and
correction loops continue across agents without turning state into a pass bypass.

**Not shipped in v1.5**, and tracked rather than implied: the `hairProfile` → `componentTree`
compiler, IK (`BoneSpec.ik` exists and nothing populates it), pose-sweep gating, blendshape-driven
expression work beyond the morph-target emitter, and clothing. Hair dynamics and strand-level hair
are out of scope permanently — a single image carries no motion, and this pipeline emits no textures
or alpha.

### v2.0 — The Plugin Update

*Shipped 2026-09-05.*

The plugin ecosystem became the product's spine rather than a line item in a far-future bundle. A
domain registry (`forge/_shared/domains/`) makes profiles pluggable: in-repo modules and installed
plugins register identically, `--profile` choices derive from what is actually present, and an
unregistered profile fails loud naming what is available. CS2 moved out of the base into
`plugin-cs2`; `animated-character` is served by `plugin-character`; the base names no domain and
infers none from a target's name. Specs pull augmentation from plugins with raise-only quality
floors, emission targets are a provenance-tracked socket, and each plugin brings its own blocking
gates. The `img2` harness (`install / add / remove / list / doctor / sync / capabilities`) owns
installation and drift detection across agent hosts.

### v2.1 — The Character Split

v2.0 left one slice unfinished on purpose: two domains had to stay in-repo so the plugin seam would
have two consumers from day one; `cs2` and `animated-character` moved out, `character` stayed.
v2.1 closes that loop. `character` joins `plugin-character`, whose existing job — Stage R rig and
animation for the `animated-character` profile — folds into the same plugin as the anatomy track.
After this release the base names no domain, finally true without qualification.

The acceptance rule is that the character build keeps emitting the same Three.js output for the same
input across the move. Each line of character anatomy, hair, and material logic is classified as
either base mechanism (driven by spec data the plugin supplies) or domain content (leaves with the
plugin); only then does any file move. The seam itself is hardened at the same time: the pass-id
set the base already enumerates is enforced at the validation site, the one file the base still
imported into the leaving set is broken, and the contract gains a clause forbidding that reverse
direction.

Out of scope: new character features, CS2 changes, environment, game pipeline, animation, AI
studio, and the procedural world bundle — those stay owned by v2.2–v2.5 and v3.0.

### v2.2 — The Environment Update

The unit of reconstruction grows from one object to a scene. Buildings, rooms, and streets become
buildable subjects; trees and vegetation get procedural treatment suited to code-only generation;
and generation becomes terrain-aware, so objects sit in a scene rather than floating in a void.
Multi-object reconstruction lands here: one reference image, several subjects, correct relative
placement and scale.

### v2.3 — The Game Pipeline Update

Assets stop being Three.js-only. First-class exporters for Unity and Unreal, a Blender bridge, and
improved FBX / OBJ / glTF output make a generated model something you can drop into an existing
production pipeline. LOD generation and collision-mesh generation cover the two things every engine
asks for and no image-to-3D tool ships by default.

### v2.4 — The Animation Update

Rigging becomes automatic: skeleton generation, skin weights, and a facial rig, with Mixamo
compatibility so existing animation libraries apply without hand work. Lip-sync preparation and
animation-ready exports close the gap between "a model exists" and "a character performs".

### v2.5 — The AI Studio Update

The pipeline gets a front door for people who don't live in a terminal: a web UI with a
drag-and-drop workflow, batch processing for more than one asset at a time, a visual prompt builder,
project management, and cloud rendering. Public showcase integration wires the studio directly to
the [live gallery](https://img2threejs-showcase.pages.dev/), so publishing a result is a button
rather than a pull request.

### v3.0 — The Procedural World Update

Multi-view reconstruction removes the single-image blind-side limit that has bounded every prior
version. Large scene generation, semantic world understanding, procedural city generation, and
interior reconstruction combine into a pipeline that produces a place rather than a prop, driven by
a multi-agent generation pipeline — all riding the plugin ecosystem and API that shipped in v2.0.

## The long view

**Phase 1 (v1.4–v1.5) — Assets.** Build high-quality individual assets: weapons, props, characters.

**Phase 1.5 (v2.0–v2.1) — Ecosystem.** The plugin architecture shipped ahead of schedule: domains,
emission targets, gates, and augmentation are extension points other people can build on.

**Phase 2 (v2.2–v2.3) — Worlds.** Build environments and game-ready content: buildings, vegetation,
streets, export pipelines.

**Phase 3 (v2.4–v2.5) — Production.** Turn generated assets into production-ready content: rigging,
animation, Blender, Unity, Unreal, and a web platform.

**Phase 4 (v3.0) — AI game-asset platform.** Generate entire playable worlds from reference images:
multi-view understanding, procedural world generation, and AI planning, all riding the v2.0
plugin ecosystem.

## Known gaps (deep-research audit — 2026-07-22)

A capability audit (NotebookLM research + `file:line` code-map) enumerated Three.js / tech-art
features the skill does not yet cover. Recorded here so they are tracked, not lost. Most are
**irrelevant to hard-surface static props** and now map onto a themed version above; one is a real
latent bug.

| # | Gap | Status / plan | Priority |
|---|---|---|---|
| G1 | SkinnedMesh + Bones + Morph targets (organic deform, facial expression) | Roadmap **v2.4 — Animation** (rig-ready topology prepared in v1.5) | deferred |
| G2 | glTF / GLB export + AnimationMixer (engine portability) | Roadmap **v2.3 — Game Pipeline** | deferred |
| G3 | ~~**InstancedMesh — real latent bug**: `instanced-cluster` has no `geometry_for()` branch; repetition systems emit a hand-rolled `Mesh` clone loop~~ | **Closed.** `geometry_for()` resolves the cluster's base primitive and the repetition emitter builds `new THREE.InstancedMesh(geo, mat, count)`; `test_repetition_system_scale.py` verifies placement by reading matrices back through `InstancedMesh.getMatrixAt` composed with `cluster.matrixWorld`, not by matching source strings | — |
| G4 | UV unwrapping / atlas, normal+AO baking (high→low), LOD, BVH; procedural-UV seams stretch at primitive joins | Partial today (procedural cyl/triplanar UV + height→normal). Baking and LOD land in **v2.3** | med |
| G5 | WebGPURenderer + TSL node materials | Deferred — architecture, not render quality | low |
| G6 | Topology / retopology / CSG boolean-merge (clean welded mesh for skinning) | Feeds **v1.5** rigging-ready topology; `three-bvh-csg` is for export/skinning, not static-prop quality | low |

**Corrections to the audit (verified against code):**
- *"IBL/PMREM not integrated"* — **inaccurate.** The generator emits `create<Type>Environment(renderer)`
  via `PMREMGenerator.fromScene(new RoomEnvironment())` (`generate_threejs_factory.py:1209-1210`);
  the showcase `Viewer` also builds a PMREM environment. IBL **is** integrated.
- *"Only a plain WebGLRenderer / no post-processing"* — **half-true by design.** The generator emits a
  `create<Type>PresentationComposer` (bloom/DOF) for the hero render, but deliberately keeps the
  evaluation render composer-free (`generate_threejs_factory.py:1251`: "plain renderer with NO
  composer — bloom blows highlights and DOF blurs edges"). A bright HDRI/bloom on the *eval* path
  would also **steal hue** from candy/anodized coats — so it must stay off the eval path.

## Contributing

img2threejs welcomes contributions, and the roadmap is responsive to real usage. If you want to work
on something above, see [CONTRIBUTING.md](CONTRIBUTING.md) — say which version's theme your work
belongs to so it lands in the right tranche. Feature requests and bug reports genuinely move
priorities: the [showcase gallery](https://img2threejs-showcase.pages.dev/) tracks likes per
category precisely so that demand, not guesswork, decides what gets built next.
